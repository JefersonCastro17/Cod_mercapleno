<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

// Manejar preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Solo permitir POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["message" => "Método no permitido"]);
    exit();
}

// Incluir archivo de conexión a la base de datos
require __DIR__ . "/../config/database.php";
require __DIR__ . "/auth.php";

// Obtener datos del body
$json = file_get_contents('php://input');
$data = json_decode($json, true);

$email = $data['email'] ?? '';
$password = $data['password'] ?? '';

// Validar campos requeridos
if (empty($email) || empty($password)) {
    http_response_code(400);
    echo json_encode(["message" => "Email y contraseña son requeridos"]);
    exit();
}

try {
    // Preparar consulta para buscar usuario
    $stmt = $pdo->prepare("SELECT id, nombre, email, password, rol, activo FROM usuarios WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Verificar si el usuario existe
    if (!$usuario) {
        http_response_code(401);
        echo json_encode(["message" => "Credenciales incorrectas"]);
        exit();
    }
    
    // Verificar si la cuenta está activa
    if ($usuario['activo'] == 0) {
        http_response_code(401);
        echo json_encode(["message" => "Cuenta no confirmada o inactiva"]);
        exit();
    }
    
    // Verificar contraseña
    if (!password_verify($password, $usuario['password'])) {
        http_response_code(401);
        echo json_encode(["message" => "Credenciales incorrectas"]);
        exit();
    }
    
    // Generar token JWT (simple)
    $token = base64_encode(json_encode([
        'user_id' => $usuario['id'],
        'email' => $usuario['email'],
        'exp' => time() + (60 * 60 * 24) // 24 horas
    ]));
    
    // Respuesta exitosa
    http_response_code(200);
    echo json_encode([
        "message" => "Inicio de sesión exitoso",
        "token" => $token,
        "user" => [
            "id" => $usuario['id'],
            "nombre" => $usuario['nombre'],
            "email" => $usuario['email'],
            "rol" => $usuario['rol']
        ]
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        "message" => "Error interno del servidor",
        "error" => $e->getMessage()
    ]);
}
?>