<?php
// Evitar que PHP envíe advertencias o espacios que dañen el JSON
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_clean();

header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: POST");

require __DIR__ . "/../config/database.php";
require __DIR__ . "/auth.php";

$data = json_decode(file_get_contents("php://input"), true);

// Validación de datos
if (
    !$data ||
    !isset($data['nombre']) ||
    !isset($data['apellido']) ||
    !isset($data['email']) ||
    !isset($data['password']) ||
    !isset($data['fecha_nacimiento'])
) {
    echo json_encode([
        "success" => false,
        "message" => "Datos incompletos"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$db = (new Database())->getConnection();

$query = $db->prepare("
    INSERT INTO usuarios (nombre, apellido, email, password, fecha_nacimiento)
    VALUES (?, ?, ?, ?, ?)
");

$result = $query->execute([
    $data['nombre'],
    $data['apellido'],
    $data['email'],
    password_hash($data['password'], PASSWORD_BCRYPT),
    $data['fecha_nacimiento']
]);

if ($result) {
    $id = $db->lastInsertId();
    $token = Auth::generarToken($id);

    echo json_encode([
        "success" => true,
        "token" => $token,
        "user" => [
            "id" => $id,
            "nombre" => $data['nombre'],
            "apellido" => $data['apellido'],
            "email" => $data['email']
        ]
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Error al registrar
echo json_encode([
    "success" => false,
    "message" => "Error al registrar usuario"
], JSON_UNESCAPED_UNICODE);
exit;
