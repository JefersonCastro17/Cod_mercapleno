<?php
require '../vendor/autoload.php';

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class Auth {
    private static $key = "CLAVE_SECRETA_123";
    private static $alg = "HS256";

    public static function generarToken($userId) {
        $payload = [
            "iss" => "WalkingMachine",
            "iat" => time(),
            "exp" => time() + (60 * 60 * 24),
            "user_id" => $userId
        ];

        return JWT::encode($payload, self::$key, self::$alg);
    }

    public static function verificarToken($token) {
        try {
            return JWT::decode($token, new Key(self::$key, self::$alg));
        } catch (Exception $e) {
            return false;
        }
    }
}
